// $(function(){
//     $('.tab').on('click', function(){
//         // tab 
//         $('.tab').removeClass('tab_active')
//         $('.tab[data-tab='+$(this).attr('data-tab')+']').toggleClass('tab_active')
       
//         // content
//         $('.content').removeClass('content_active')
//         $('.content[data-tab='+$(this).attr('data-tab')+']').toggleClass('content_active') 
       
//     })
// })

// $(function(){
// $('.button_more').on('click', function(){
//     $('#exampleModal').arcticmodal();

// })
// });
$(function(){
    $('.your-class').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
      });
})





